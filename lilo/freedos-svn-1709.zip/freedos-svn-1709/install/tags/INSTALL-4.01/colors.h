/* this is a hack for graph.h */

#define _BLACK_          0
#define _BLUE_           1
#define _GREEN_          2
#define _CYAN_           3
#define _RED_            4
#define _MAGENTA_        5
#define _BROWN_          6
#define _WHITE_          7

#define _GRAY_           8
#define _LIGHTBLUE_      9
#define _LIGHTGREEN_     10
#define _LIGHTCYAN_      11
#define _LIGHTRED_       12
#define _LIGHTMAGENTA_   13
#define _YELLOW_         14
#define _BRIGHTWHITE_    15
