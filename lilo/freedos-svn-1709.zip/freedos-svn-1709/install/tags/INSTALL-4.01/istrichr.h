int index_strichr (const char *str, int ch);
