void titlebar (const char *title);
void statusbar (const char *status);
