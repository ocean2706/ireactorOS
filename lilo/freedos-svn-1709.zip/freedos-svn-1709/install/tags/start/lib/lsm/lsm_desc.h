int lsm_description (int y0, int x0, int maxlines, const char *lsmfile);
