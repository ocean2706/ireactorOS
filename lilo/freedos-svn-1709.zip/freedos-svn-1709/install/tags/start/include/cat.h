int
cat_file (const char *filename, int y0, int maxlines);
