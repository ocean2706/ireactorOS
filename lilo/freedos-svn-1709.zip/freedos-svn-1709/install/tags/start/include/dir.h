#ifdef unix
#define DIR_CHAR '/'
#else
#define DIR_CHAR '\\'
#endif
